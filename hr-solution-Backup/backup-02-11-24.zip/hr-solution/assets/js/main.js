/**
 * Template Name: Right HR Solutions - v1.0
 * Template URL: https://zohirs.com
 * Author: Zohir
 */

// JavaScript Document

$(window).on('load', function () {
    "use strict";
    /*----------------------------------------------------*/
    /*	Preloader
    /*----------------------------------------------------*/
    var preloader = $('#preloader'),
        loader = preloader.find('#loading');
    loader.fadeOut();
    preloader.delay(400).fadeOut('slow');
});

$(document).ready(function () {
    "use strict";

    /*----------------------------------------------------*/
    /*	Navigtion Menu
    /*----------------------------------------------------*/
    const hamburger = document.querySelector(".hamburger");
    const navMenu = document.querySelector(".navbar");
    const navMenuOverlay = document.querySelector(".nav-overlay");

    if (hamburger) {
        hamburger.addEventListener("click", () => {
            hamburger.classList.toggle("active");
            navMenu.classList.toggle("active");
            navMenuOverlay.classList.toggle("active");
        });
    }

    /*----------------------------------------------------*/
    /*	Scroll to Section with Offset for Fixed Menu
    /*----------------------------------------------------*/
    if (window.location.hash) {
        const targetSection = document.querySelector(window.location.hash);
        if (targetSection) {
            setTimeout(() => {
                window.scrollTo({
                    top: targetSection.getBoundingClientRect().top + window.scrollY - 90, // Adjusted offset
                    behavior: 'smooth'
                });
            }, 200); // Delay in milliseconds for layout adjustments
        }
    }

    /*----------------------------------------------------*/
    /*	returns the year (four digits)
    /*----------------------------------------------------*/
    var year = new Date().getFullYear();
    document.getElementById("year").innerHTML = year;

    /*----------------------------------------------------*/
    /*	Video Play on click
    /*----------------------------------------------------*/
    const playButton = document.getElementById("playButton");
    const videoThumb = document.getElementById("videoThumb");
    const videoPlayer = document.getElementById("videoPlayer");

    if (playButton) {
        playButton.addEventListener("click", function () {
            videoThumb.style.display = "none";
            videoPlayer.style.display = "block";
            const iframe = document.querySelector("#videoPlayer iframe");
            iframe.src = videoUrl; // Set src with autoplay
        });
    }

    const videoCloseBtn = document.getElementById("videoCloseBtn");
    if (videoCloseBtn) {
        videoCloseBtn.addEventListener("click", function () {
            videoPlayer.style.display = "none";
            videoThumb.style.display = "block";
            const iframe = document.querySelector("#videoPlayer iframe");
            iframe.src = ""; // Reset src to stop the video
        });
    }

    /*----------------------------------------------------*/
    /*	Newsletter Form
    /*----------------------------------------------------*/
    const newsletterEmail = document.getElementById("newsletterEmail");
    const submitNewsletter = document.getElementById("submitNewsletter");

    if (newsletterEmail && submitNewsletter) {
        // Enable submit button if email is valid
        newsletterEmail.addEventListener("input", function () {
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            submitNewsletter.disabled = !emailPattern.test(newsletterEmail.value);
        });

        // Append email to action URL before form submission
        window.preloadEmail = function () {
            const email = newsletterEmail.value;
            const formAction = `/contact-us.html?email=${encodeURIComponent(email)}#contact_us_form`;
            window.location.href = formAction; // Redirect to the new URL with the email
            return false; // Prevent default form submission
        };
    }

    /*----------------------------------------------------*/
    /*	Contact Form Email Population
    /*----------------------------------------------------*/
    const urlParams = new URLSearchParams(window.location.search);
    const email = urlParams.get("email"); // Retrieve the email parameter
    const emailAddressField = document.getElementById("emailAddress");

    if (email && emailAddressField) {
        emailAddressField.value = email; // Populate the email field
    }

    /*----------------------------------------------------*/
    /*	Set Selected Radio Button Based on URL Parameter
    /*----------------------------------------------------*/
    const selectedCategory = urlParams.get("category");

    if (selectedCategory) {
        const radioButton = document.getElementById(selectedCategory);
        if (radioButton) {
            radioButton.checked = true;
        }
    }

    /*----------------------------------------------------*/
    /*	Terms and Conditions Checkbox
    /*----------------------------------------------------*/
    const acceptTermsCheckbox = document.getElementById("acceptTermsConditions");
    const submitButton = document.getElementById("submitButton");

    if (acceptTermsCheckbox && submitButton) {
        acceptTermsCheckbox.addEventListener("change", function () {
            submitButton.disabled = !acceptTermsCheckbox.checked;
        });
    }
});

// Scroll event for navigation menu
$(window).on('scroll', function () {
    "use strict";
    var b = $(window).scrollTop();
    if (b > 80) {
        $(".main-header").addClass("fixd");
        $(".back-to-top").addClass("active");
    } else {
        $(".main-header").removeClass("fixd");
        $(".back-to-top").removeClass("active");
    }
});



