/**
 * Template Name: Right HR Solutions - v1.0
 * Template URL: https://zohirs.com
 * Author: Zohir
 */

// JavaScript Document

$(window).on('load', function() {
	"use strict";
	/*----------------------------------------------------*/
	/*	Preloader
	/*----------------------------------------------------*/
	var preloader = $('#preloader'),
		loader = preloader.find('#loading');
	loader.fadeOut();
	preloader.delay(400).fadeOut('slow');
});


$(document).ready(function() {
	"use strict";
	/*----------------------------------------------------*/
	/*	Navigtion Menu
	/*----------------------------------------------------*/
	const hamburger = document.querySelector(".hamburger");
	const navMenu = document.querySelector(".navbar");
	const navMenuOverlay = document.querySelector(".nav-overlay");
	hamburger.addEventListener("click", () => {
		hamburger.classList.toggle("active");
		navMenu.classList.toggle("active");
		navMenuOverlay.classList.toggle("active");
	});

	/*----------------------------------------------------*/
	/*	returns the year (four digits)
	/*----------------------------------------------------*/
	var year = new Date().getFullYear()
	document.getElementById("year").innerHTML = (year);
});

$(window).on('scroll', function() {
	"use strict";
	/*----------------------------------------------------*/
	/*	Navigtion Menu Scroll
	/*----------------------------------------------------*/
	var b = $(window).scrollTop();
	if (b > 80) {
		$(".main-header").addClass("fixd");
		$(".back-to-top").addClass("active");
	} else {
		$(".main-header").removeClass("fixd");
		$(".back-to-top").removeClass("active");
	}

});